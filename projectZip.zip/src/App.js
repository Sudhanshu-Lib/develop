import React, { useState } from 'react';
import logo from './logo.svg';
import './App.css';

const App = ({ deck }) => {
  console.log('deck app', deck);
  const [value, setValue] = useState();
  const [error, setError] = useState('');
  let [result, setResult] = useState([]);
  const updateField = e => {
    const input = parseInt(e.target.value);
    setValue(input);
  }
  const handleClick = () => {
    const input = document.getElementById('fname');
    if ((deck.length) % input?.value !== 0) {
      setError('Invalid players entry, Please enter valid no of players')
    } else {
      const players = deck?.length / parseInt(input.value);
      const result = new Array(Math.ceil(deck?.length / players))
      .fill()
      .map(_ => deck.splice(0, players));
      setResult(result)
      console.log('result', result);
    }
  }
  return (
    <div className="App">
      <header className="App-header">
        <img src={logo} className="App-logo" alt="logo" />
        <label for="input">Input value:</label><br />
        <input type="text" id="fname" name="fname" onChange={updateField} />
        <label>{error}</label>
        <input type="button" onClick={handleClick} value="Submit" />        
        <div className="full-width">
          Output values <br />
          <div>
          {result?.map((player, idx) => {
            return (
              <div className="flex-container" key={idx}>
                Player{idx+1}:::::::: <br />
                {player.map((i, idx) => (
                  <div className="flex-container">
                    <label key={idx} for="value">
                      {`${i?.Suit}-${i.Value}`}
                    </label>
                  </div>
                ))}
              </div>
            );
          })}
          </div>
        </div>
      </header>
    </div>
  );
}

export default App;
